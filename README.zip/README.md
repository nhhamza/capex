# Gestión Inmobiliaria - Real Estate Profitability SaaS (Spain)

A simple, maintainable MVP for managing real estate investment properties and calculating profitability metrics in the Spanish market.

## Tech Stack

- **Frontend**: Vite + React 18 + TypeScript
- **UI**: Material-UI v6+ (DataGrid, DatePickers)
- **Forms**: react-hook-form + zod
- **Charts**: Recharts
- **Dates**: Day.js
- **HTTP**: Axios (with interceptors)
- **Routing**: React Router v6
- **State**: React Context + useReducer (simple, no external state lib)
- **Testing**: Vitest + @testing-library/react

## Setup

### Prerequisites

- Node.js 18+ 
- pnpm (or npm/yarn)

### Installation

```bash
# Install dependencies
pnpm install

# Run development server
pnpm dev

# Build for production
pnpm build

# Run tests
pnpm test
```

The app will be available at `http://localhost:3000`.

### Demo Login

- Email: `demo@example.com`
- Password: Any password (mock auth)

## Project Structure

```
/src
  /app             # Core app setup (main, routes, theme)
  /auth            # Auth context + guard (mock in-memory)
  /components      # Shared components (Layout, KPI, Money, etc.)
  /modules
    /properties    # Properties CRUD, calculations, types, API
      /pages       # PropertiesList, PropertyCreate, PropertyDetail + tabs
    /dashboard     # Dashboard with KPIs and charts
    /cashflow      # Cashflow page (stub)
    /reports       # Reports page (stub with TODOs)
    /settings      # Settings page
    /onboarding    # Onboarding wizard
  /utils           # axiosClient, format, date helpers
  /mocks           # In-memory database (db.ts, seed.ts)
```

## Features Implemented

### Core Functionality
- ✅ Multi-tenant by organizationId (basic filtering in mock)
- ✅ Auth mock (simple in-memory, ready to replace)
- ✅ Properties CRUD with full detail tabs
- ✅ Leases (contracts) management
- ✅ Recurring expenses (gastos fijos)
- ✅ One-off expenses / CapEx (gastos puntuales)
- ✅ Loan/financing with French amortization
- ✅ Onboarding wizard stub

### Calculations
- ✅ Purchase price + closing costs (ITP, notary, registry, AJD, renovation, etc.)
- ✅ Gross rental yield
- ✅ NOI (Net Operating Income)
- ✅ Net Cap Rate
- ✅ Yield on Cost
- ✅ With debt: ADS (Annual Debt Service), Cash-on-Cash, DSCR, LTV
- ✅ French amortization schedule with optional interest-only period
- ✅ Unit tests for all calculation functions

### UI/UX
- ✅ AppBar + Drawer layout
- ✅ Dashboard with 4 KPIs + 12-month chart
- ✅ Properties list with DataGrid (metrics columns)
- ✅ Property detail with 8 tabs:
  - Resumen (KPIs + chart)
  - Compra (purchase + closing costs)
  - Contrato (lease details)
  - Gastos Fijos (recurring expenses)
  - CapEx (one-off expenses)
  - Docs (file upload stub)
  - Financiación (loan + amortization table)
  - Notas (notes textarea)
- ✅ Forms with react-hook-form + zod validation
- ✅ Snackbar notifications
- ✅ Confirm dialogs

## TODO: Backend Integration

Currently, the app uses an in-memory mock database (`/mocks/db.ts`). To integrate with a real backend:

### Option 1: Supabase
1. Create a Supabase project
2. Define tables: `properties`, `leases`, `recurring_expenses`, `one_off_expenses`, `loans`, `organizations`, `users`
3. Replace `src/modules/properties/api.ts` to use Supabase client:
   ```typescript
   import { createClient } from '@supabase/supabase-js';
   const supabase = createClient(url, key);
   ```
4. Add RLS policies for multi-tenancy by `organizationId`
5. Replace auth mock with Supabase Auth

### Option 2: Firebase/Firestore
1. Create Firebase project + Firestore database
2. Define collections with same structure
3. Replace API functions to use Firestore SDK
4. Add security rules for multi-tenancy
5. Replace auth with Firebase Auth

### Option 3: Custom REST API (Node/Express/Azure)
1. Build a REST API with endpoints matching current API functions
2. Update `axiosClient.ts` baseURL to point to real backend
3. Implement JWT auth and replace mock auth context
4. Add organizationId middleware/guards on backend

### Auth Migration
- Replace `/auth/authContext.tsx` mock with real provider (Supabase/Firebase/Auth0)
- Update `axiosClient.ts` interceptors to add real JWT tokens
- Remove `MOCK_USERS` object

### File Storage
- Replace `FileUpload.tsx` stub with real storage:
  - Supabase Storage
  - Firebase Storage  
  - Azure Blob Storage
  - AWS S3

## TODOs for Production

### High Priority
- [ ] Replace mock auth with real authentication provider
- [ ] Connect to real backend (Supabase/Firebase/custom API)
- [ ] Implement file upload and storage
- [ ] Add error boundaries
- [ ] Add loading states and skeletons
- [ ] Implement real PDF/Excel export (use jsPDF, xlsx libs)
- [x] **Complete Cashflow page with monthly/annual views** ✅
- [ ] Add user management and team features
- [ ] Implement default parameters in Settings

### Nice to Have
- [ ] Add property images/photos
- [ ] Tenant management (inquilinos)
- [ ] Payment tracking and receipts
- [ ] Email notifications (rent due, maintenance)
- [ ] Mobile responsive improvements
- [ ] Dark mode
- [ ] Export/import data (CSV)
- [ ] Multi-language support
- [ ] Property comparison tool
- [ ] Tax calculations (IRPF, etc.)

### Testing
- [ ] Add more component tests
- [ ] Add E2E tests with Playwright/Cypress
- [ ] Add integration tests with backend

### DevOps
- [ ] Set up CI/CD pipeline
- [ ] Add environment variables management
- [ ] Deploy to Vercel/Netlify/Azure Static Web Apps
- [ ] Set up monitoring and error tracking (Sentry)
- [ ] Add analytics

## Code Principles

This project follows **boring, maintainable** principles:

- **YAGNI**: Only implemented what's needed for MVP
- **Small files**: Components ≤150-200 lines
- **Shallow structure**: Minimal indirection
- **Explicit over clever**: Clear naming, no magic
- **Simple state**: React Context + useReducer, no complex state libs
- **No premature abstraction**: Direct implementations, refactor when needed
- **Pure functions**: All calculations are pure and testable

## License

MIT (or your preferred license)

## Contributing

This is an MVP. Feel free to fork and extend for your needs.

For questions or issues, please open a GitHub issue.
#   c a p e x  
 #   c a p e x  
 