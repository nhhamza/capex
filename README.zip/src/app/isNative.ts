import { Capacitor } from "@capacitor/core";

export const isNative = () => Capacitor.isNativePlatform();
